package com.aloha.projectmgr.dao;

import com.aloha.projectmgr.model.ProjectEmployee;

public interface ProjectEmployeeDao extends Dao {

	public void saveEmp(ProjectEmployee employee) ;
}
