package com.aloha.test_controller;


import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.aloha.projectmgr.controller.EmployeeController;
import com.aloha.projectmgr.service.*;
import com.aloha.projectmgr.model.*;

public class MockitoControllerTest {
	@InjectMocks
    private EmployeeController employeeController;
	@Mock
    private EmpService employeeService;
	
	@Before
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
	
	
	@Test
    public void testGetEmployeeById() {
		ProjectEmployee emp = new ProjectEmployee();
		emp.setProjectId(1);
		
		List<ProjectEmployee> emp1 =employeeController.getEmployeeModel();
		emp1.size();
		/*
		int id =employeeService.getEmployee().get(1).getProjectId();
		System.out.println("-----employeeService-----"+id);
		
	
		List<ProjectEmployee> empList = employeeController.getEmployeeModel();
		System.out.println("-----employeeController-----"+empList.get(1).getProjectId());*/
       // verify(userRepository).findOne(1l);

        assertEquals(1, 1);
    }

}
