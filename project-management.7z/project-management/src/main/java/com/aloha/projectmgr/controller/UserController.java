package com.aloha.projectmgr.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aloha.projectmgr.model.User;
import com.aloha.projectmgr.repository.UserDataRepo;
import com.aloha.projectmgr.service.UserDataService;
import com.aloha.projectmgr.service.UserViewService;
import com.aloha.projectmgr.view_map.UserView;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserDataService userService;
	@Autowired
	private UserDataRepo userDataRepo;
	@Autowired
	private UserViewService userViewService;

	@PostMapping
	public String saveUser(@RequestParam(required = false) Long id, @RequestParam(required = false) String name) {
		User user = new User();
		user.setU_Id(id);
		user.setU_Name(name);
		System.out.println("user id" + id + name);
		userService.save(user);
		return "save user";
	}

	@GetMapping("/getUser/{id}")
	public User getUser(@PathVariable(value = "id") Long id) {
		System.out.println("---- id->" + id);
		User user = new User();
		user.setU_Id(id);
		return userService.getUserById(user);
	}

	@GetMapping("/getAllUser")
	public List<User> getAllUser() {
		System.out.println("getAllUser");
		return userDataRepo.findAll();
	}

	@GetMapping("/getUserView/{id}")
	public List<UserView> userView(@PathVariable(value = "id") int viewId) {
		System.out.println("viewId-->" + viewId);
		return userViewService.findAllRelated();

	}

}
