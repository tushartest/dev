package com.aloha.projectmgr.service;

import java.util.List;

import com.aloha.projectmgr.model.User;
import com.aloha.projectmgr.view_map.UserView;


public interface UserDataService {
	
	User save(User user);
		
	User getUserById(User u_Id);
	
	List<User> getAllUser();
    
}
