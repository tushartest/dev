package com.aloha.projectmgr.service;

import java.util.List;
import com.aloha.projectmgr.model.ProjectEmployee;


public interface EmpService {

	String saveEmployee(ProjectEmployee projectEmployee);
	
	List<ProjectEmployee> getEmployee();
	
	ProjectEmployee getSingleEmployee(int id);
}
