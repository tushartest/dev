package com.aloha.projectmgr.model;

import java.io.Serializable;

import javax.annotation.Generated;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class User implements Serializable{

	@Id
	
	@Column( columnDefinition = "Long default 1l")
	private Long u_Id;
	@Column
	private String u_Name;
	public Long getU_Id() {
		return u_Id;
	}
	public void setU_Id(Long u_Id) {
		this.u_Id = u_Id;
	}
	public String getU_Name() {
		return u_Name;
	}
	public void setU_Name(String u_Name) {
		this.u_Name = u_Name;
	}
		
}
