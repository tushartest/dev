package com.aloha.projectmgr.controller;

import java.util.List;
import java.util.Map;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.aloha.projectmgr.dao.EmployeeService;
import com.aloha.projectmgr.model.ProjectEmployee;
import com.aloha.projectmgr.service.EmpService;


@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping("/emp")
public class EmployeeController {

@Autowired 
private EmpService employeeService;	

	@PostMapping	
	public String saveEmployee(@RequestParam Map<String,String> requestParams) {
		
		ProjectEmployee employee=new ProjectEmployee();
		employee.setEmp_id(Integer.parseInt(requestParams.get("id")));
		employee.setProjectId(Integer.parseInt(requestParams.get("emp_id")));
		employee.setEmp_email(requestParams.get("name"));
        employee.setEmp_name(requestParams.get("emial"));	
        employee.setEmp_contactNo(requestParams.get("contactNo"));		
        employeeService.saveEmployee(employee) ;
		return "ok";
	} 
	
    @GetMapping	
	public String saveEmp(@RequestParam int pgId, @RequestParam int emp_id, @RequestParam(required = false) String emp_name, @RequestParam(required = false) String emp_email
            , @RequestParam String emp_contactNo) {
    	System.out.println("---"+pgId+ emp_id+ emp_name + emp_email+ emp_contactNo);
		return "ok";
	} 
    
    @PostMapping
    @RequestMapping("/apiSaveEmp")
	public String saveEmployeeModel(@RequestBody ProjectEmployee projectEmployee) {		
			System.out.println("projectEmployee->"+projectEmployee);
            employeeService.saveEmployee(projectEmployee) ;
		    return "Employee saved successfully";
	} 
    
    
    @GetMapping
    @RequestMapping("/apiGetEmps")
	public @ResponseBody List<ProjectEmployee> getEmployeeModel() {		
			System.out.println("projectEmployee->");
			return employeeService.getEmployee() ;
		    
	} 
    
    @GetMapping
    @RequestMapping(value ="/apiGetEmp",produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ProjectEmployee getSingleEmployee(@PathParam("id")  Integer id) {		
			System.out.println("getSingleEmployee->"+id);
			return employeeService.getSingleEmployee(id) ;
		    
	} 
    
    
    
}
