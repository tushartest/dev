package com.aloha.projectmgr.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.aloha.projectmgr.dao.ProjectEmployeeDao;
import com.aloha.projectmgr.model.ProjectEmployee;
import com.aloha.projectmgr.service.EmpService;

@Service
public class EmployeeServiceImpl implements EmpService {

@Autowired 
private ProjectEmployeeDao projectEmployeeDao;

    @Override
	public String saveEmployee(ProjectEmployee projectEmployee) {
		projectEmployeeDao.saveEmp(projectEmployee);
		return "save successfuly";
	}

	@Override
	public List<ProjectEmployee> getEmployee() {
		
		return projectEmployeeDao.getAllEmployee();
	}

	@Override
	public ProjectEmployee getSingleEmployee(int id) {
		ProjectEmployee pemp=new ProjectEmployee();
		ProjectEmployee employee=projectEmployeeDao.findById(id);
		pemp.setEmp_id(employee.getEmp_id());
		pemp.setEmp_contactNo(employee.getEmp_contactNo());
		pemp.setEmp_email(employee.getEmp_email());
		pemp.setEmp_name(employee.getEmp_name());
		pemp.setProjectId(employee.getProjectId());
		return pemp;
	}

}
