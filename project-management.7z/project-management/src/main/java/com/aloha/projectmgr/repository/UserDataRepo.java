package com.aloha.projectmgr.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.aloha.projectmgr.model.User;
import com.aloha.projectmgr.view_map.UserView;

public interface UserDataRepo extends JpaRepository<User,Long> {

	User findOne(Long u_Id);

	List<User> findAll();	
	
}
