package com.aloha.projectmgr.daoImpl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.aloha.projectmgr.dao.Dao;
import com.aloha.projectmgr.dao.GenericDao;
import com.aloha.projectmgr.dao.ProjectEmployeeDao;
import com.aloha.projectmgr.dao.ProjectTaskDao;
import com.aloha.projectmgr.dto.ProjectDetailsDto;
import com.aloha.projectmgr.dto.ProjectPaymentScheduleDto;
import com.aloha.projectmgr.model.ProjectEmployee;
import com.aloha.projectmgr.view_map.UserView;

@Repository
public class ProjectEmployeeDaoImpl extends GenericDao implements ProjectEmployeeDao {
	Session session = null;

	@Override
	public void saveEmp(ProjectEmployee employee) {
		session = getSessionFactory().openSession();
		session.save(employee);
	}

	@Override
	public List<ProjectEmployee> getAllEmployee() {
		session = getSessionFactory().openSession();
		session.createQuery("FROM user_view order by id").list();
		
		
		//session.createQuery("SELECT v FROM UserView v", UserView.class).getResultList();
		
		System.out.println("userView--->,..");
		return session.createQuery("from ProjectEmployee order by projectId").list();
	}

	@Override
	public ProjectEmployee findById(int id) {
		session = getSessionFactory().openSession();
		ProjectEmployee pEmp = (ProjectEmployee) session.load("com.aloha.projectmgr.model.ProjectEmployee", id);
		return pEmp;

	}

}
