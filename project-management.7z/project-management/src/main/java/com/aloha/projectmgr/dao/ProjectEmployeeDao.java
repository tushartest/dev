package com.aloha.projectmgr.dao;

import java.util.List;

import com.aloha.projectmgr.model.ProjectEmployee;



public interface ProjectEmployeeDao extends Dao {

	public void saveEmp(ProjectEmployee employee) ;
	
	List<ProjectEmployee> getAllEmployee();
	
	ProjectEmployee findById(int id);
}

