package com.aloha.projectmgr.view_map;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

import org.hibernate.annotations.Immutable;


@Entity
@Immutable
@Table(name="user_view")
public class UserView {
	@Id	
	private Long id;
	private String name;
	private String email;
	
	public String getEmail() {
		return email;
	}
	public Long getId() {
		return id;
	}
	public String getName() {
		return name;
	}	
	
	
	
}
