package com.aloha.projectmgr.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aloha.projectmgr.repository.UserViewRepository;
import com.aloha.projectmgr.service.UserViewService;
import com.aloha.projectmgr.view_map.UserView;

@Service
public class UserViewServiceImpl implements UserViewService{

	@Autowired private UserViewRepository UserViewRepo; 
	
	//UserViewRepo.createQuery("SELECT v FROM UserView v", UserView.class).getResultList();
	
	@Override
	public List<UserView> findAllUser() {
	    
		return UserViewRepo.findAll();
		
		
		
	}

	@Override
	public List<UserView> findAllRelated() {
		
		return UserViewRepo.findAll();
	}
	
	

	

}
