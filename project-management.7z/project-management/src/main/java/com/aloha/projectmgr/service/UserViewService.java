package com.aloha.projectmgr.service;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.aloha.projectmgr.view_map.UserView;

public interface UserViewService {
	
	@Query("SELECT v FROM view_user v")
	 List<UserView>  findAllRelated();
			 
	 List<UserView> findAllUser(); 
	
	
	
}
