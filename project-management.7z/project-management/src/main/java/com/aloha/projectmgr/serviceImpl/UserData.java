package com.aloha.projectmgr.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aloha.projectmgr.model.User;
import com.aloha.projectmgr.repository.UserDataRepo;
import com.aloha.projectmgr.service.UserDataService;
import com.aloha.projectmgr.view_map.UserView;

@Service
public class UserData implements UserDataService {

	@Autowired
    private UserDataRepo userRepository;

	


	@Override
	public User save(User user) {
		
		return userRepository.save(user);
	}

	@Override
	public User getUserById(User user) {
		System.out.println("user-<"+user.getU_Id());
		User userData =userRepository.findOne(user.getU_Id());
		
		return userData;
	}

	@Override
	public List<User> getAllUser() {
		
		return userRepository.findAll();
	}

}
