package com.aloha.projectmgr.dao;

import java.util.List;

import com.aloha.projectmgr.model.ProjectEmployee;

public interface EmployeeService {

	/*String saveEmployee(ProjectEmployee projectEmployee);
	
	List<ProjectEmployee> getEmployee();*/
}
